```python
#iport libries
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import os
```


```python
#load data into the jupyter
a1= pd.read_csv(r"C:\Users\ALUU PHILIP\Downloads\homicide_by_countries.csv")
```


```python
a1.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Location</th>
      <th>Region</th>
      <th>Subregion</th>
      <th>Rate</th>
      <th>Count</th>
      <th>Year</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Afghanistan</td>
      <td>Asia</td>
      <td>Southern Asia</td>
      <td>6.7</td>
      <td>2474</td>
      <td>2018</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Albania</td>
      <td>Europe</td>
      <td>Southern Europe</td>
      <td>2.1</td>
      <td>61</td>
      <td>2020</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Algeria</td>
      <td>Africa</td>
      <td>Northern Africa</td>
      <td>1.3</td>
      <td>580</td>
      <td>2020</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Andorra</td>
      <td>Europe</td>
      <td>Southern Europe</td>
      <td>2.6</td>
      <td>2</td>
      <td>2020</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Angola</td>
      <td>Africa</td>
      <td>Middle Africa</td>
      <td>4.8</td>
      <td>1217</td>
      <td>2012</td>
    </tr>
  </tbody>
</table>
</div>



a1.head()


```python
#show how the table looks like
a1.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Location</th>
      <th>Region</th>
      <th>Subregion</th>
      <th>Rate</th>
      <th>Count</th>
      <th>Year</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Afghanistan</td>
      <td>Asia</td>
      <td>Southern Asia</td>
      <td>6.7</td>
      <td>2474</td>
      <td>2018</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Albania</td>
      <td>Europe</td>
      <td>Southern Europe</td>
      <td>2.1</td>
      <td>61</td>
      <td>2020</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Algeria</td>
      <td>Africa</td>
      <td>Northern Africa</td>
      <td>1.3</td>
      <td>580</td>
      <td>2020</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Andorra</td>
      <td>Europe</td>
      <td>Southern Europe</td>
      <td>2.6</td>
      <td>2</td>
      <td>2020</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Angola</td>
      <td>Africa</td>
      <td>Middle Africa</td>
      <td>4.8</td>
      <td>1217</td>
      <td>2012</td>
    </tr>
  </tbody>
</table>
</div>




```python
#select year and count, group by year
n1=a1[['Year','Count']]
n2=n1.groupby(['Year']).sum()
n2
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Count</th>
    </tr>
    <tr>
      <th>Year</th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>2006</th>
      <td>205</td>
    </tr>
    <tr>
      <th>2007</th>
      <td>26</td>
    </tr>
    <tr>
      <th>2008</th>
      <td>1702</td>
    </tr>
    <tr>
      <th>2009</th>
      <td>69</td>
    </tr>
    <tr>
      <th>2010</th>
      <td>304</td>
    </tr>
    <tr>
      <th>2011</th>
      <td>2481</td>
    </tr>
    <tr>
      <th>2012</th>
      <td>15378</td>
    </tr>
    <tr>
      <th>2013</th>
      <td>5782</td>
    </tr>
    <tr>
      <th>2014</th>
      <td>3042</td>
    </tr>
    <tr>
      <th>2015</th>
      <td>2447</td>
    </tr>
    <tr>
      <th>2016</th>
      <td>6222</td>
    </tr>
    <tr>
      <th>2017</th>
      <td>6924</td>
    </tr>
    <tr>
      <th>2018</th>
      <td>31599</td>
    </tr>
    <tr>
      <th>2019</th>
      <td>55319</td>
    </tr>
    <tr>
      <th>2020</th>
      <td>232047</td>
    </tr>
    <tr>
      <th>2021</th>
      <td>15299</td>
    </tr>
  </tbody>
</table>
</div>




```python
#plot line chart, to show the count of sucide across the year
n2.plot(kind='line', color='red')
plt.title('Count of sucide across the year')
plt.legend().set_visible(False)
```


    
![png](output_6_0.png)
    



```python
a1.index
```




    RangeIndex(start=0, stop=195, step=1)




```python
#Check for null values
a1.isnull()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Location</th>
      <th>Region</th>
      <th>Subregion</th>
      <th>Rate</th>
      <th>Count</th>
      <th>Year</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
    </tr>
    <tr>
      <th>1</th>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
    </tr>
    <tr>
      <th>2</th>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
    </tr>
    <tr>
      <th>3</th>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
    </tr>
    <tr>
      <th>4</th>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>190</th>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
    </tr>
    <tr>
      <th>191</th>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
    </tr>
    <tr>
      <th>192</th>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
    </tr>
    <tr>
      <th>193</th>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
    </tr>
    <tr>
      <th>194</th>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
    </tr>
  </tbody>
</table>
<p>195 rows × 6 columns</p>
</div>




```python
#show the columns
a1.columns
```




    Index(['Location', 'Region', 'Subregion', 'Rate', 'Count', 'Year'], dtype='object')




```python

```


```python
a2.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Location</th>
      <th>Region</th>
      <th>Subregion</th>
      <th>Count</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Afghanistan</td>
      <td>Asia</td>
      <td>Southern Asia</td>
      <td>2474</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Albania</td>
      <td>Europe</td>
      <td>Southern Europe</td>
      <td>61</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Algeria</td>
      <td>Africa</td>
      <td>Northern Africa</td>
      <td>580</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Andorra</td>
      <td>Europe</td>
      <td>Southern Europe</td>
      <td>2</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Angola</td>
      <td>Africa</td>
      <td>Middle Africa</td>
      <td>1217</td>
    </tr>
  </tbody>
</table>
</div>




```python
#create a pie chart grouped by Region
a3=a2.groupby(['Region'])['Count'].sum().reset_index()
b1= a3.sort_values(by= 'Count', ascending=False)
b1.plot(x='Region', y='Count',kind='pie', labels=a3.Region, autopct='%1.2f%%')
plt.legend().set_visible(False)
plt.title('Percentage of Sucide across Regions')

```




    Text(0.5, 1.0, 'Percentage of Sucide across Regions')




    
![png](output_12_1.png)
    


# a3.plot(x='Region',y = 'Count', kind= 'pie', label= 'Region').sum(). 


```python

a3.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Year</th>
      <th>Region</th>
      <th>Count</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>2018</td>
      <td>Asia</td>
      <td>2474</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2020</td>
      <td>Europe</td>
      <td>61</td>
    </tr>
    <tr>
      <th>2</th>
      <td>2020</td>
      <td>Africa</td>
      <td>580</td>
    </tr>
    <tr>
      <th>3</th>
      <td>2020</td>
      <td>Europe</td>
      <td>2</td>
    </tr>
    <tr>
      <th>4</th>
      <td>2012</td>
      <td>Africa</td>
      <td>1217</td>
    </tr>
  </tbody>
</table>
</div>




```python
#using seaborn to visualize data 
o1=a3.sort_values(by ='Count', ascending=False)
sns.barplot(x=o1['Region'], y = o1['Count'])
```




    <Axes: xlabel='Region', ylabel='Count'>




    
![png](output_15_1.png)
    



```python
r5=a3.groupby(['Year'])
```


```python
#group by Region
s1 =a2.groupby(['Region'])['Count'].sum()

s1.head()
```




    Region
    Africa       99481
    Americas    153597
    Asia        105552
    Europe       19869
    Oceania        347
    Name: Count, dtype: int64




```python

```


```python
#Create a bar chart matplotlib
#groupped by Region
fw=a2.groupby (['Region'])['Count'].sum().sort_values(ascending=False)

fw.plot(x='Region', y='Count', kind = 'bar')
```




    <Axes: xlabel='Region'>




    
![png](output_19_1.png)
    



```python

```


```python
fw=a2.groupby (['Region'])['Count'].sum().sort_values(ascending=False)
fw
```




    Region
    Americas    153597
    Asia        105552
    Africa       99481
    Europe       19869
    Oceania        347
    Name: Count, dtype: int64




```python


```


```python
#select rows where the region is either Europe or Asia
#select rows where the year is greater than 2016
#group it by region and year, also unstack the table
k1=a1[(a1['Region']=='Asia')|(a1['Region']=='Europe')]
k2= k1[k1['Year']>2016][['Year', 'Region', 'Count']]
k3= k2.groupby(['Region','Year'])['Count'].sum()
k3_unstack= k3.unstack(level=0)
k3_unstack.dropna()

```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th>Region</th>
      <th>Asia</th>
      <th>Europe</th>
    </tr>
    <tr>
      <th>Year</th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>2017</th>
      <td>1787.0</td>
      <td>3670.0</td>
    </tr>
    <tr>
      <th>2018</th>
      <td>16923.0</td>
      <td>883.0</td>
    </tr>
    <tr>
      <th>2019</th>
      <td>6458.0</td>
      <td>249.0</td>
    </tr>
    <tr>
      <th>2020</th>
      <td>53516.0</td>
      <td>15066.0</td>
    </tr>
  </tbody>
</table>
</div>




```python
#convert the year from float to string
k3_unstack.index= k3_unstack.index.astype(int).astype(str)
```


```python

```


```python
#create a line plot comparing Asia and Europe from 2017 to 2021
k3_unstack.plot(kind='line',figsize=(10,6))
plt.xlabel('Year')
plt.ylabel('Count')
plt.title('Count of sucide in Asia and Europe over the year')

```




    Text(0.5, 1.0, 'Count of sucide in Asia and Europe over the year')




    
![png](output_26_1.png)
    



```python
h8=a1.groupby(['Subregion'])['Count'].sum().sort_values(ascending=False)
h8
```




    Subregion
    South America             78872
    Southern Asia             58631
    Central America           47371
    Western Africa            46318
    South-Eastern Asia        25314
    Eastern Africa            23669
    Northern America          22317
    Southern Africa           21479
    Eastern Europe            14604
    Western Asia              11638
    Eastern Asia               8563
    Northern Africa            5538
    Caribbean                  5037
    Middle Africa              2477
    Northern Europe            2097
    Western Europe             2075
    Central Asia               1406
    Southern Europe            1093
    Australia, New Zealand      347
    Name: Count, dtype: int64




```python

```


```python
h8.plot(kind='bar', figsize = (7,3), color = 'skyblue')
```




    <Axes: xlabel='Subregion'>




    
![png](output_29_1.png)
    



```python
#show a table of subregions with their average count
j1=a2.groupby(['Subregion'])['Count'].mean().sort_values(ascending=False)
```


```python
j

```




    Subregion
    Southern Asia             6514.555556
    South America             6067.076923
    Central America           5921.375000
    Northern America          4463.400000
    Southern Africa           4295.800000
    Western Africa            4210.727273
    South-Eastern Asia        2531.400000
    Eastern Africa            1577.933333
    Eastern Europe            1460.400000
    Eastern Asia              1223.285714
    Northern Africa           1107.600000
    Middle Africa              619.250000
    Western Asia               581.900000
    Central Asia               281.200000
    Western Europe             230.555556
    Caribbean                  201.480000
    Australia, New Zealand     173.500000
    Northern Europe            139.800000
    Southern Europe             64.294118
    Name: Count, dtype: float64




```python
j1.index
```




    Index(['Southern Asia', 'South America', 'Central America', 'Northern America',
           'Southern Africa', 'Western Africa', 'South-Eastern Asia',
           'Eastern Africa', 'Eastern Europe', 'Eastern Asia', 'Northern Africa',
           'Middle Africa', 'Western Asia', 'Central Asia', 'Western Europe',
           'Caribbean', 'Australia, New Zealand', 'Northern Europe',
           'Southern Europe'],
          dtype='object', name='Subregion')




```python
print(j1.shape)
```

    (19,)
    


```python
print(j1.head())
```

    0    6514.555556
    1    6067.076923
    2    5921.375000
    3    4463.400000
    4    4295.800000
    Name: Count, dtype: float64
    


```python
print(j1.shape)
```

    (19,)
    


```python
j1.reset_index(drop=True, inplace=True)
```


```python
j1.head()
```




    Subregion
    Southern Asia       6514.555556
    South America       6067.076923
    Central America     5921.375000
    Northern America    4463.400000
    Southern Africa     4295.800000
    Name: Count, dtype: float64




```python
print(j1.shape)
```

    (19,)
    


```python
print(j1.head())
j1.dropna()
print(j1.shape)
```

    Subregion
    Southern Asia       6514.555556
    South America       6067.076923
    Central America     5921.375000
    Northern America    4463.400000
    Southern Africa     4295.800000
    Name: Count, dtype: float64
    (19,)
    


```python

```


```python
j1.round(2)
```




    Subregion
    Southern Asia             6514.56
    South America             6067.08
    Central America           5921.38
    Northern America          4463.40
    Southern Africa           4295.80
    Western Africa            4210.73
    South-Eastern Asia        2531.40
    Eastern Africa            1577.93
    Eastern Europe            1460.40
    Eastern Asia              1223.29
    Northern Africa           1107.60
    Middle Africa              619.25
    Western Asia               581.90
    Central Asia               281.20
    Western Europe             230.56
    Caribbean                  201.48
    Australia, New Zealand     173.50
    Northern Europe            139.80
    Southern Europe             64.29
    Name: Count, dtype: float64




```python
j1.index
```




    Index(['Southern Asia', 'South America', 'Central America', 'Northern America',
           'Southern Africa', 'Western Africa', 'South-Eastern Asia',
           'Eastern Africa', 'Eastern Europe', 'Eastern Asia', 'Northern Africa',
           'Middle Africa', 'Western Asia', 'Central Asia', 'Western Europe',
           'Caribbean', 'Australia, New Zealand', 'Northern Europe',
           'Southern Europe'],
          dtype='object', name='Subregion')




```python

```


```python
data= {
    'category':j1.index,
    'values': j1.values,
    
}
m1=pd.DataFrame(data)
m1.dropna()

```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>category</th>
      <th>values</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Southern Asia</td>
      <td>6514.555556</td>
    </tr>
    <tr>
      <th>1</th>
      <td>South America</td>
      <td>6067.076923</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Central America</td>
      <td>5921.375000</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Northern America</td>
      <td>4463.400000</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Southern Africa</td>
      <td>4295.800000</td>
    </tr>
    <tr>
      <th>5</th>
      <td>Western Africa</td>
      <td>4210.727273</td>
    </tr>
    <tr>
      <th>6</th>
      <td>South-Eastern Asia</td>
      <td>2531.400000</td>
    </tr>
    <tr>
      <th>7</th>
      <td>Eastern Africa</td>
      <td>1577.933333</td>
    </tr>
    <tr>
      <th>8</th>
      <td>Eastern Europe</td>
      <td>1460.400000</td>
    </tr>
    <tr>
      <th>9</th>
      <td>Eastern Asia</td>
      <td>1223.285714</td>
    </tr>
    <tr>
      <th>10</th>
      <td>Northern Africa</td>
      <td>1107.600000</td>
    </tr>
    <tr>
      <th>11</th>
      <td>Middle Africa</td>
      <td>619.250000</td>
    </tr>
    <tr>
      <th>12</th>
      <td>Western Asia</td>
      <td>581.900000</td>
    </tr>
    <tr>
      <th>13</th>
      <td>Central Asia</td>
      <td>281.200000</td>
    </tr>
    <tr>
      <th>14</th>
      <td>Western Europe</td>
      <td>230.555556</td>
    </tr>
    <tr>
      <th>15</th>
      <td>Caribbean</td>
      <td>201.480000</td>
    </tr>
    <tr>
      <th>16</th>
      <td>Australia, New Zealand</td>
      <td>173.500000</td>
    </tr>
    <tr>
      <th>17</th>
      <td>Northern Europe</td>
      <td>139.800000</td>
    </tr>
    <tr>
      <th>18</th>
      <td>Southern Europe</td>
      <td>64.294118</td>
    </tr>
  </tbody>
</table>
</div>




```python

```


```python
print(m1.shape)
```

    (19, 2)
    


```python
m1.index
```




    RangeIndex(start=0, stop=19, step=1)




```python
m1.columns
```




    Index(['category', 'values'], dtype='object')




```python

```


```python

```


```python

```
